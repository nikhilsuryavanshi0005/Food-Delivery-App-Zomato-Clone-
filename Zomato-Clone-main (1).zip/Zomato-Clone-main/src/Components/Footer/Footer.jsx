import { GetTheLocalities } from "./GetTheApp"

export const Footer = () => {

    return(

        <>

        <GetTheLocalities />

        </>
    )
}