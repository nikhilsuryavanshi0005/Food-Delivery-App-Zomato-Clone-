
export const FoodData = [

    {
        id : 1,
        food : "Cake",
        route : "cake",
        image : "https://b.zmtcdn.com/data/dish_photos/b24/163ec0c041094f6e4f1efc81cf32bb24.png"
    },

    {
        id : 2,
        food : "Ice Cream",
        route : "ice-cream",
        image : "https://b.zmtcdn.com/data/pictures/chains/4/18949234/d60d487c5c887ce9b7da458c0253389d_o2_featured_v2.jpg"
    },

    {
        id : 3,
        food : "Coffee",
        route : "coffee",
        image : "https://b.zmtcdn.com/data/images/cuisines/unlabelled_v2_1/1040.jpg"
    },

    {
        id : 4,
        food : "Shake",
        route : "shake",
        image : "https://b.zmtcdn.com/data/dish_images/8187d3223ac2cc42cc24f723c92877511634805403.png"
    },

    {
        id : 5,
        food : "Chaat",
        route : "chaat",
        image : "https://b.zmtcdn.com/data/dish_images/1437bc204cb5c892cb22d78b4347f4651634827140.png"
    },

    {
        id : 6,
        food : "Burger",
        route : "burger",
        image : "https://b.zmtcdn.com/data/dish_images/ccb7dc2ba2b054419f805da7f05704471634886169.png"
    },

    {
        id : 7,
        food : "Pizza",
        route : "pizza",
        image : "https://b.zmtcdn.com/data/o2_assets/d0bd7c9405ac87f6aa65e31fe55800941632716575.png"
    },

    {
        id : 8,
        food : "French Fries",
        route : "chaat",
        image : "https://b.zmtcdn.com/data/o2_assets/13bdf0d4c96d44e6ddb21fedde0fe4081632716661.png"
    }
]